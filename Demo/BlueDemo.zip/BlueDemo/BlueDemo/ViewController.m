//
//  ViewController.m
//  BlueDemo
//
//  Created by lgy on 2017/6/28.
//  Copyright © 2017年 LGY****HD. All rights reserved.
//

#import "ViewController.h"
#import <CoreBluetooth/CoreBluetooth.h>

#define  _WIDTH                                          [UIScreen mainScreen].bounds.size.width
#define  _HEIGHT                                        [UIScreen mainScreen].bounds.size.height

@interface ViewController ()<CBPeripheralDelegate,CBCentralManagerDelegate,UITableViewDelegate,UITableViewDataSource>{
    //系统蓝牙设备管理对象，可以把他理解为主设备，通过他，可以去扫描和链接外设
    CBCentralManager *manager;
}

@property(nonatomic, strong)UITableView *tableView;
@property(nonatomic, strong)NSMutableArray *beaconArr;//存放扫描的iBeacon的数组



@end

@implementation ViewController


- (UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 20, _WIDTH, _HEIGHT -20) style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
    }
    return _tableView;
}

- (NSMutableArray *)beaconArr {
    if (!_beaconArr) {
        _beaconArr = [NSMutableArray array];
    }
    return _beaconArr;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self.view addSubview:self.tableView];

    manager = [[CBCentralManager alloc]initWithDelegate:self queue:dispatch_get_main_queue()];
}


#pragma mark -------------- tableViewDelegate
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *ident = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ident];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:ident];
    }
    
    CBPeripheral *peripheral = [self.beaconArr objectAtIndex:indexPath.row];
    cell.textLabel.text = peripheral.name;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    CBPeripheral *peripheral = [self.beaconArr objectAtIndex:indexPath.row];
    [manager connectPeripheral:peripheral options:nil];
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.beaconArr.count;
}


-(void)centralManagerDidUpdateState:(CBCentralManager *)central{
    
    switch (central.state) {
            
        case CBCentralManagerStateUnknown:
            
            NSLog(@">>>CBCentralManagerStateUnknown");
            
            break;
            
        case CBCentralManagerStateResetting:
            
            NSLog(@">>>CBCentralManagerStateResetting");
            
            break;
            
        case CBCentralManagerStateUnsupported:
            
            NSLog(@">>>CBCentralManagerStateUnsupported");
            
            break;
            
        case CBCentralManagerStateUnauthorized:
            
            NSLog(@">>>CBCentralManagerStateUnauthorized");
            
            break;
            
        case CBCentralManagerStatePoweredOff:
            
            NSLog(@">>>CBCentralManagerStatePoweredOff");
            
            break;
            
        case CBCentralManagerStatePoweredOn:
            
            NSLog(@">>>CBCentralManagerStatePoweredOn");
            //开始扫描周围的外设
            /*
             第一个参数nil就是扫描周围所有的外设，扫描到外设后会进入
             - (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI;
             */
            [manager scanForPeripheralsWithServices:nil options:nil];
            
            break;
            
        default:
            
            break;
    }
}

//扫描到设备会进入方法
-(void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI{
    
    [self.beaconArr addObject:peripheral];
    
    if ([peripheral.name isEqualToString:@"BC01"]) {

        NSLog(@"-------- %@",advertisementData);
        [manager stopScan];
        [_tableView reloadData];
    }
    
}

//连接外设成功的委托
- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral{
    
    NSLog(@">>>连接到名称为（%@）的设备-成功   *******     %@  ------ %@",peripheral.name,peripheral,central);

    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"设备连接成功" message:peripheral.name delegate:nil cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    [alertView show];
}

//外设连接失败的委托
- (void)centralManager:(CBCentralManager *)central didFailToConnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error{
    
    NSLog(@">>>连接到名称为（%@）的设备-失败,原因:%@",[peripheral name],[error localizedDescription]);
}

//断开外设的委托
- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error{
    
    NSLog(@">>>外设连接断开连接 %@: %@\n", [peripheral name], [error localizedDescription]);
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
